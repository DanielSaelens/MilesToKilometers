import java.awt.Point;
public class StringPlay {

	public static void main(String[] args) {
		
		String string_1 = "C++ is cool" ;
		String string_2 = "I love Java";
		
		 string_1 =  new String("Java is cool");
		 
		 System.out.println(string_1);
		 
		 Point point1 = new Point(3,4);
		 Point point2 = new Point(3,4);
		 
		 
		System.out.println(point1 == point2);
		System.out.println(point1.equals(point2));
		
		
		String name_1 = "Daniel";
		String name_2 = "daniel";
		
		System.out.println(name_1.equals(name_2));
		System.out.println(name_1.equalsIgnoreCase(name_2));
		
		
		 
		 
	
		
	}

}
